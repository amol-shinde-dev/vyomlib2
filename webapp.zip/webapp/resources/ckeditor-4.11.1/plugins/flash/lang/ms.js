﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'flash', 'ms', {
	access: 'Script Access', // MISSING
	accessAlways: 'Always', // MISSING
	accessNever: 'Never', // MISSING
	accessSameDomain: 'Same domain', // MISSING
	alignAbsBottom: 'Bawah Mutlak',
	alignAbsMiddle: 'Pertengahan Mutlak',
	alignBaseline: 'Garis Dasar',
	alignTextTop: 'Atas Text',
	bgcolor: 'Warna Latarbelakang',
	chkFull: 'Allow Fullscreen', // MISSING
	chkLoop: 'Loop', // MISSING
	chkMenu: 'Enable Flash Menu', // MISSING
	chkPlay: 'Auto Play', // MISSING
	flashvars: 'Variables for Flash', // MISSING
	hSpace: 'Ruang Melintang',
	properties: 'Flash Properties', // MISSING
	propertiesTab: 'Properties', // MISSING
	quality: 'Quality', // MISSING
	qualityAutoHigh: 'Auto High', // MISSING
	qualityAutoLow: 'Auto Low', // MISSING
	qualityBest: 'Best', // MISSING
	qualityHigh: 'High', // MISSING
	qualityLow: 'Low', // MISSING
	qualityMedium: 'Medium', // MISSING
	scale: 'Scale', // MISSING
	scaleAll: 'Show all', // MISSING
	scaleFit: 'Exact Fit', // MISSING
	scaleNoBorder: 'No Border', // MISSING
	title: 'Flash Properties', // MISSING
	vSpace: 'Ruang Menegak',
	validateHSpace: 'HSpace must be a number.', // MISSING
	validateSrc: 'Sila taip sambungan URL',
	validateVSpace: 'VSpace must be a number.', // MISSING
	windowMode: 'Window mode', // MISSING
	windowModeOpaque: 'Opaque', // MISSING
	windowModeTransparent: 'Transparent', // MISSING
	windowModeWindow: 'Window' // MISSING
} );
