﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'flash', 'km', {
	access: 'Script Access', // MISSING
	accessAlways: 'ជានិច្ច',
	accessNever: 'កុំ',
	accessSameDomain: 'Same domain', // MISSING
	alignAbsBottom: 'Abs Bottom', // MISSING
	alignAbsMiddle: 'Abs Middle', // MISSING
	alignBaseline: 'បន្ទាត់ជាមូលដ្ឋាន',
	alignTextTop: 'លើអត្ថបទ',
	bgcolor: 'ពណ៌ផ្ទៃខាងក្រោយ',
	chkFull: 'អនុញ្ញាត​ឲ្យ​ពេញ​អេក្រង់',
	chkLoop: 'ចំនួនដង',
	chkMenu: 'បង្ហាញ មឺនុយរបស់ Flash',
	chkPlay: 'លេងដោយស្វ័យប្រវត្ត',
	flashvars: 'អថេរ Flash',
	hSpace: 'គំលាតទទឹង',
	properties: 'ការកំណត់ Flash',
	propertiesTab: 'លក្ខណៈ​សម្បត្តិ',
	quality: 'គុណភាព',
	qualityAutoHigh: 'ខ្ពស់​ស្វ័យ​ប្រវត្តិ',
	qualityAutoLow: 'ទាប​ស្វ័យ​ប្រវត្តិ',
	qualityBest: 'ល្អ​បំផុត',
	qualityHigh: 'ខ្ពស់',
	qualityLow: 'ទាប',
	qualityMedium: 'មធ្យម',
	scale: 'ទំហំ',
	scaleAll: 'បង្ហាញទាំងអស់',
	scaleFit: 'ត្រូវល្មម',
	scaleNoBorder: 'មិនបង្ហាញស៊ុម',
	title: 'ការកំណត់ Flash',
	vSpace: 'គំលាតបណ្តោយ',
	validateHSpace: 'HSpace must be a number.', // MISSING
	validateSrc: 'សូមសរសេរ អាស័យដ្ឋាន URL',
	validateVSpace: 'VSpace must be a number.', // MISSING
	windowMode: 'Window mode', // MISSING
	windowModeOpaque: 'Opaque', // MISSING
	windowModeTransparent: 'ភាព​ថ្លា',
	windowModeWindow: 'វីនដូ'
} );
