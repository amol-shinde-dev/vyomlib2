﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'hu', {
	find: 'Keresés',
	findOptions: 'Beállítások',
	findWhat: 'Keresett szöveg:',
	matchCase: 'Kis- és nagybetű megkülönböztetése',
	matchCyclic: 'Ciklikus keresés',
	matchWord: 'Csak ha ez a teljes szó',
	notFoundMsg: 'A keresett szöveg nem található.',
	replace: 'Csere',
	replaceAll: 'Az összes cseréje',
	replaceSuccessMsg: '%1 egyezőség cserélve.',
	replaceWith: 'Csere erre:',
	title: 'Keresés és csere'
} );
