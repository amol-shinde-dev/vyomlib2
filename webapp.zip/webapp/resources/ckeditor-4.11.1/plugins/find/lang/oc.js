﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'oc', {
	find: 'Recercar',
	findOptions: 'Opcions de recèrca',
	findWhat: 'Recercar :',
	matchCase: 'Respectar la cassa',
	matchCyclic: 'Boclar',
	matchWord: 'Mot entièr unicament',
	notFoundMsg: 'Lo tèxte especificat pòt pas èsser trobat.',
	replace: 'Remplaçar',
	replaceAll: 'Remplaçar tot',
	replaceSuccessMsg: '%1 ocurréncia(s) remplaçada(s).',
	replaceWith: 'Remplaçar per  :',
	title: 'Recercar e remplaçar'
} );
