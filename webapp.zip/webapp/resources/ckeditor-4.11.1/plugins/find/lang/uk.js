﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'uk', {
	find: 'Пошук',
	findOptions: 'Параметри Пошуку',
	findWhat: 'Шукати:',
	matchCase: 'Враховувати регістр',
	matchCyclic: 'Циклічна заміна',
	matchWord: 'Збіг цілих слів',
	notFoundMsg: 'Вказаний текст не знайдено.',
	replace: 'Заміна',
	replaceAll: 'Замінити все',
	replaceSuccessMsg: '%1 співпадінь(ня) замінено.',
	replaceWith: 'Замінити на:',
	title: 'Знайти і замінити'
} );
