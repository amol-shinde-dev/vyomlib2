﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'et', {
	find: 'Otsi',
	findOptions: 'Otsingu valikud',
	findWhat: 'Otsitav:',
	matchCase: 'Suur- ja väiketähtede eristamine',
	matchCyclic: 'Jätkatakse algusest',
	matchWord: 'Ainult terved sõnad',
	notFoundMsg: 'Otsitud teksti ei leitud.',
	replace: 'Asenda',
	replaceAll: 'Asenda kõik',
	replaceSuccessMsg: '%1 vastet asendati.',
	replaceWith: 'Asendus:',
	title: 'Otsimine ja asendamine'
} );
