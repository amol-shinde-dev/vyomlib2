﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'ar', {
	find: 'بحث',
	findOptions: 'Find Options',
	findWhat: 'البحث بـ:',
	matchCase: 'مطابقة حالة الأحرف',
	matchCyclic: 'مطابقة دورية',
	matchWord: 'مطابقة بالكامل',
	notFoundMsg: 'لم يتم العثور على النص المحدد.',
	replace: 'إستبدال',
	replaceAll: 'إستبدال الكل',
	replaceSuccessMsg: 'تم استبدال 1% من الحالات ',
	replaceWith: 'إستبدال بـ:',
	title: 'بحث واستبدال'
} );
